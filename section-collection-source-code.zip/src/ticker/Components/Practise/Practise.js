import React from 'react';

const Practise = () => {
    return (
        <div>
            ghgfhgf
        </div>
    );
};

export default Practise;