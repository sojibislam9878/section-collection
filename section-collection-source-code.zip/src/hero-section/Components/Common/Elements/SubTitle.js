
const SubTitle = ({ isSubTitle, subTitleArea }) => {
    return isSubTitle && subTitleArea
}
export default SubTitle;