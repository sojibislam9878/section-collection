const Title = ({ isTitle, titleArea }) => {
    return isTitle && titleArea
}
export default Title;